<?php
	define("DB_SERVER","localhost");
	define("DB_USER","root");
	define("DB_NAME","mydb");
	define("DB_PASS","");
	

	
?>
<?php

echo "test page";
?>